package com.niit.dao;

public class ForumDaoImpl {

}
