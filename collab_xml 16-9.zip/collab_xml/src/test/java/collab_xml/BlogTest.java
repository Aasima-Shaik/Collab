package collab_xml;

import static org.junit.Assert.*;



import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.dao.BlogDaoImpl;
import com.niit.model.Blog;


public class BlogTest {

	private Blog blog;
	
	@Autowired
	private BlogDaoImpl blogDaoImpl;
	
	@Autowired
	private AnnotationConfigApplicationContext context;
	
	@Test
	public void test() {
		fail("Not yet implemented");
	}
	
	@Before
	public void init() {
		blog = new Blog();
		System.out.println("In test case");
		
		context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		System.out.println("after refresh");
		
		blog.setBid("101");
		blog.setbUserName("aasima");
		blog.setBcontent("kfjdhgihfsjerfwegftruhgfsjdfiursiytuer");
		blog.setBtitle("blog1");
		System.out.println("blog==="+blog);
		blogDaoImpl = (BlogDaoImpl) context.getBean("blogDaoImpl");
		blogDaoImpl.createNewBlog(blog);
		
	}
}
