package com.niit.collab.service;
import java.util.*;
import  com.niit.collab.dao.*;
import com.niit.collab.model.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UserServiceImpl implements UserService
{
	@Autowired
	private UserDAO userdao;
	
	@Transactional
	public void setUserDao(UserDAO userdao)
	{
		this.userdao=userdao;
	}

	@Transactional
	public void saveOrUpdate(User user) {
		userdao.saveOrUpdate(user);
		
	}

	@Transactional
	public User getUserById(int userid) {
		
		return userdao.getUserById(userid);
	}

	@Transactional
	public List<User> list() {
		
		return userdao.list();
	}

	@Transactional
	public User getUserByname(String username) {
		
		return userdao.getUserByname(username);
	}
	
}