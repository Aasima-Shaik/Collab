package com.niit.collab.service;

import com.niit.collab.dao.*;
import com.niit.collab.model.*;
import java.util.*;

public interface UserService
{
	public void setUserDao(UserDAO userdao);
	public void saveOrUpdate(User user);
	public User getUserById(int userid);
	public List<User> list();
	public User getUserByname(String username);
}