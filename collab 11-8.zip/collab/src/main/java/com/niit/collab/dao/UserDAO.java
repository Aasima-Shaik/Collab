package com.niit.collab.dao;

import com.niit.collab.model.*;
import java.util.*;

public interface UserDAO
{
	public void saveOrUpdate(User user);
	public User getUserById(int userid);
	public  List<User> list();
	public User getUserByname(String username);
	
	
}
