package com.niit.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.model.UserDetails;

@Repository("userDAO")
public class UserDAOImpl implements UserDAO {
	public UserDAOImpl()
	{
	}
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public UserDAOImpl(SessionFactory sessionFactory)
	{
		this.sessionFactory=sessionFactory;
	}

	@Transactional
	public List<UserDetails> list() {
		// TODO Auto-generated method stub
		@SuppressWarnings("unchecked")
		List<UserDetails> list=(List<UserDetails>) sessionFactory.getCurrentSession()
				.createCriteria(UserDetails.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
		return list;
	}

	public void saveOrUpdate(UserDetails collabUser) {
		System.out.println("am in userDAO saveOrUpdate");
		// TODO Auto-generated method stub
		sessionFactory.openSession().saveOrUpdate(collabUser);
		System.out.println("exiting userdao save or update");
	}

}
