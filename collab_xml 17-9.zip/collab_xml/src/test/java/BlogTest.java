import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.dao.BlogDaoImpl;
import com.niit.model.Blog;

public class BlogTest {
	@Autowired
static	BlogDaoImpl blogDaoImpl;
	
	public static void main(String[] args)
		{
		@SuppressWarnings("resource")
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		Blog cb = new Blog();
		//Blog cb=(Blog)context.getBean("blog");
		
		 System.out.println("after daos");
		
		cb.setBid("101");
		cb.setbUserName("aasima");
		cb.setBcontent("kfjdhgihfsjerfwegftruhgfsjdfiursiytuer");
		cb.setBtitle("blog1");
		blogDaoImpl=(BlogDaoImpl) context.getBean("blogDaoImpl");
		System.out.println("entering values");
		blogDaoImpl.createNewBlog(cb);
		System.out.println("after save or update");
		}
	
	}
