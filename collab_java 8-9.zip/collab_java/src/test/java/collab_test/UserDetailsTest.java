package collab_test;

import junit.framework.TestCase;
import static org.junit.Assert.*;

import org.hibernate.usertype.UserVersionType;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.dao.UserDAO;
import com.niit.model.UserDetails;

public class UserDetailsTest {


	private  UserDetails usertable;
	
	@Autowired
	private UserDAO usertabledao;
	
	@Autowired
	private AnnotationConfigApplicationContext context;
	
	@Test
	public void test() {
		fail("Not yet implemented");
	}
	
	
	@Before
	public void init()
	{
		usertable = new UserDetails();
		System.out.println("am in test case");
		
		context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		System.out.println("i am in test case after refresh");
		//usertable = (UserTable)context.getBean("usertable");
		System.out.println("user table="+usertable);
		usertable.setId("10");
		usertable.setName("sec");
		usertable.setPassword("sect@123");
		usertable.setEmail("sec@niit.com");
		usertable.setStatus('A');
		usertable.setReason("djfhgkszdn");
		usertable.setMobile("7766");
		usertable.setAddress("navkethan 2nd");
		
		usertabledao =(UserDAO) context.getBean("userDAO");
		usertabledao.saveOrUpdate(usertable);
		
	}

	}
