import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.config.ApplicationContextConfig;
import com.niit.dao.BlogDAO;
import com.niit.model.Blog;

public class BlogTest {
	@Autowired
static	BlogDAO blogDAO;
	
	public static void main(String[] args)
		{
		@SuppressWarnings("resource")
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		Blog cb=(Blog)context.getBean("blog");
		
		 System.out.println("after daos");
		
		cb.setId("101");
		cb.setTitle("blog1");
		cb.setDescription("about blog1");
		cb.setUser_id("u_101");
		blogDAO=(BlogDAO) context.getBean("blogDAO");
		System.out.println("entering values");
		blogDAO.saveOrUpdate(cb);
		System.out.println("after save or update");
		}
	
	}
