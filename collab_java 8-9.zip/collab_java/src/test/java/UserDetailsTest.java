import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.config.ApplicationContextConfig;
import com.niit.dao.UserDAO;
import com.niit.model.UserDetails;

public class UserDetailsTest {
	@Autowired
static	UserDAO userDAO;
	
	public static void main(String[] args)
		{
		@SuppressWarnings("resource")
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		UserDetails cb=(UserDetails)context.getBean("userDetails");
		
		 System.out.println("after daos");
		
		cb.setId("002");
		cb.setName("ruby");
		cb.setPassword("ru");
		cb.setEmail("ruby@gmail.com");
		cb.setStatus('A');
		cb.setReason("jsfuhshf");
		cb.setMobile("1234567890");
		cb.setAddress("lsngjiuheb");
		userDAO=(UserDAO) context.getBean("userDAO");
		System.out.println("entering values");
		userDAO.saveOrUpdate(cb);
		System.out.println("after save or update");
		}
	
	}
