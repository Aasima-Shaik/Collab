package com.niit.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.model.Blog;

@Repository("blogDAO")
public class BlogDAOImpl implements BlogDAO {
	public BlogDAOImpl()
	{
		
	}

	@Autowired
	private SessionFactory sessionFactory;
	
	public BlogDAOImpl(SessionFactory sessionFactory)
	{
		this.sessionFactory=sessionFactory;
	}

	@Transactional
	public List<Blog> list() {
		@SuppressWarnings("unchecked")
		List<Blog> list=(List<Blog>) sessionFactory.getCurrentSession()
				.createCriteria(Blog.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
		return list;
	}

	@Transactional
	public void saveOrUpdate(Blog collab_blog) {
		System.out.println("in save or update");
		sessionFactory.getCurrentSession().saveOrUpdate(collab_blog);
		System.out.println("in save or update of daoimpl");
		
	}
	
}
