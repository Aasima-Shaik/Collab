package com.niit.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import java.awt.PageAttributes.MediaType;
import java.util.*;
import com.niit.dao.UserDAO;
import com.niit.model.UserDetails;

@RestController
public class UserController 
{
	@SuppressWarnings("unused")
	@Autowired
	private UserDAO userdao;
	
	@Autowired
	UserDetails userDetails;
	
	
	@RequestMapping(value="/UserDetails", method= RequestMethod.GET)
	public ResponseEntity<List<UserDetails>> listAllUserDetails()
	{
		System.out.println("calling method listalluserdetails");
		List<UserDetails> userDetails = userdao.list();
		if(userDetails.isEmpty())
		{
			System.out.println("No users are available");
			return new ResponseEntity<List<UserDetails>>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<UserDetails>>(userDetails, HttpStatus.OK);
	}
	

}
